var app = angular.module("postserviceapp",[]);

app.controller("postserviceCrtrl", function($scope, $http) {
    $scope.EnterBloodPressure = null;
    $scope.EnterEnterAge = null;
    $scope.EnterEnterWeight = null;
    $scope.EnterEnterGlucoseLevel = null;
    $scope.EnterBloodGroup = null;
    
    
    $scope.postdata =function( EnterBloodPressure,EnterEnterAge,EnterEnterWeight,EnterEnterGlucoseLevel,EnterBloodGroup ){
        // creation ob that will pass to the sevice
        var data= {
            EnterBloodPressure:EnterBloodPressure,
            EnterEnterAge:EnterEnterAge,
            EnterEnterWeight:EnterEnterWeight,
            EnterEnterGlucoseLevel:EnterEnterGlucoseLevel,
            EnterBloodGroup:EnterBloodGroup,


        }
        $http.post("https://jsonplaceholder.typicode.com/posts", JSON.stringify(data))
        .then(function(response){
            console.log(response);
            if(response.data){
                
                $scope.EnterBloodPressure= response.data.EnterBloodPressure;
                $scope.EnterEnterAge= response.data.EnterEnterAge;
                $scope.EnterEnterWeight= response.data.EnterEnterWeight;
                $scope.EnterEnterGlucoseLevel= response.data.EnterEnterGlucoseLevel;
                $scope.EnterBloodGroup= response.data.EnterBloodGroup;
            }
        },function(error){
            console.log(error)
        } )
    }
}
    
)   