var app = angular.module("postserviceapp",[]);

app.controller("postserviceCrtrl", function($scope, $http) {
    $scope.EnterPatientName = null;
    $scope.EnterHospitalLocation = null;
    $scope.EnterAppointmentDate = null;
    $scope.EnterAppointmentTime = null;
    $scope.EnterReasonforAppointment = null;
    
    
    $scope.postdata =function( EnterPatientName,EnterHospitalLocation,EnterAppointmentDate,EnterAppointmentTime,EnterReasonforAppointment ){
        // creation ob that will pass to the sevice
        var data= {
            EnterPatientName:EnterPatientName,
            EnterHospitalLocation:EnterHospitalLocation,
            EnterAppointmentDate:EnterAppointmentDate,
            EnterAppointmentTime:EnterAppointmentTime,
            EnterReasonforAppointment:EnterReasonforAppointment,


        }
        $http.post("https://jsonplaceholder.typicode.com/posts", JSON.stringify(data))
        .then(function(response){
            console.log(response);
            if(response.data){
                
                $scope.EnterReasonforAppointment= response.data.EnterReasonforAppointment;
                $scope.EnterHospitalLocati= response.data.EnterHospitalLocati;
                $scope.EnterAppointmentDate= response.data.EnterAppointmentDate;
                $scope.EnterAppointmentTime= response.data.EnterAppointmentTime;
                $scope.EnterReasonforAppointmen= response.data.EnterReasonforAppointmen;
            }
        },function(error){
            console.log(error)
        } )
    }
}
    
)   